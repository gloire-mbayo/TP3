package com.example.pishart;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private static final int RETOUR_PRENDRE_PHOTO = 1;
    private Button btnPrendrePhoto;
    private ImageView imgAffichePhoto;
    private String photoPath = null;

    public MainActivity(ImageButton imgAffichePhoto) {
        imgAffichePhoto = imgAffichePhoto;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intActivity();
    }
    private void intActivity(){
        btnPrendrePhoto = (Button)findViewById(R.id.btnPrendrePhoto);
        imgAffichePhoto = (ImageView)findViewById(R.id.imgAffichePhoto);

    }
    private void createOneclicBtnPrendrePhoto(){
        btnPrendrePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
    private void prendreUnephoto(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(intent.resolveActivity(getPackageManager()) !=null){
            String time = new SimpleDateFormat(  "yyyymmdd_HHmmss").format(new Date());
            File photoDir =getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File photoFile = null;
            try {
                photoFile = File.createTempFile("photo"+time, ".jpg", photoDir);
            } catch (IOException e) {
                e.printStackTrace();
            }
            photoPath = photoFile.getAbsolutePath();
            Uri photoUri = FileProvider.getUriForFile( MainActivity.this, MainActivity.this.getApplicationContext().getPackageName()+".provider", photoFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            startActivityForResult(intent,RETOUR_PRENDRE_PHOTO );

        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==RETOUR_PRENDRE_PHOTO && requestCode==RESULT_OK){
            Bitmap image = BitmapFactory.decodeFile(photoPath);
            imgAffichePhoto.setImageBitmap(image);
        }
    }
}